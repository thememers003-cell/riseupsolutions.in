import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: "FinTrack AI",
      category: "Fintech",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800",
      description: "An AI-powered expense tracker and investment advisor built for modern millennials."
    },
    {
      title: "HealthPulse",
      category: "Healthcare",
      image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=800",
      description: "Telemedicine platform connecting patients with specialized doctors globally."
    },
    {
      title: "EcoSmart",
      category: "Sustainability",
      image: "https://images.unsplash.com/photo-1542601906990-b4d3fb7d5fa5?auto=format&fit=crop&q=80&w=800",
      description: "IoT dashboard for monitoring and optimizing energy consumption in smart homes."
    }
  ];

  return (
    <section id="projects" className="py-24 bg-black text-white">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex justify-between items-end mb-12"
        >
          <div>
            <h2 className="text-blue-500 font-semibold tracking-wider uppercase mb-2">Our Portfolio</h2>
            <h3 className="text-4xl font-bold">Built by RiseUp Students</h3>
          </div>
          <a href="#" className="hidden md:flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors">
            View all projects <ArrowUpRight size={18} />
          </a>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              whileHover={{ y: -10 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.4 }}
              className="group relative overflow-hidden rounded-2xl bg-slate-900 border border-slate-800"
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <span className="text-xs font-medium text-blue-400 bg-blue-400/10 px-2 py-1 rounded mb-2 inline-block">
                      {project.category}
                    </span>
                    <h4 className="text-xl font-bold">{project.title}</h4>
                  </div>
                  <a href="#" className="p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors">
                    <ArrowUpRight size={20} />
                  </a>
                </div>
                <p className="text-gray-400 text-sm leading-relaxed">
                  {project.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-8 text-center md:hidden">
          <a href="#" className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors">
            View all projects <ArrowUpRight size={18} />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Projects;

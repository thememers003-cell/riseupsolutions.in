import { motion } from 'framer-motion';
import { Code, BrainCircuit, Rocket } from 'lucide-react';

const Programs = () => {
  return (
    <section id="programs" className="py-24 bg-black text-white relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-blue-500 font-semibold tracking-wider uppercase mb-2">Our Programs</h2>
          <h3 className="text-4xl md:text-5xl font-bold">Master the Future</h3>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <motion.div
            whileHover={{ y: -10 }}
            className="group relative bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-1 overflow-hidden border border-slate-700 hover:border-blue-500 transition-colors duration-300"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl" />
            
            <div className="relative bg-slate-900 rounded-[22px] p-8 md:p-12 h-full flex flex-col md:flex-row gap-8 items-center">
              <div className="flex-1 space-y-6">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 text-blue-400 font-medium text-sm border border-blue-500/20">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
                  </span>
                  Enrolling Now
                </div>
                
                <h3 className="text-3xl md:text-4xl font-bold text-white group-hover:text-blue-200 transition-colors">
                  AI & Machine Learning Bootcamp
                </h3>
                
                <p className="text-slate-400 text-lg">
                  An intensive 8-week program designed to take you from basics to building advanced AI models. 
                  Master Python, TensorFlow, and deploy real-world AI applications.
                </p>

                <ul className="space-y-3">
                  {[
                    "8 Weeks Duration",
                    "Live Mentorship",
                    "Hands-on Projects",
                    "Placement Assistance"
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-slate-300">
                      <div className="h-1.5 w-1.5 rounded-full bg-blue-500" />
                      {item}
                    </li>
                  ))}
                </ul>

                <button className="mt-8 px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-all w-full md:w-auto shadow-lg shadow-blue-900/20">
                  Apply for Batch 2024
                </button>
              </div>

              <div className="w-full md:w-1/3 flex flex-col gap-4">
                 <div className="p-4 bg-slate-800 rounded-xl border border-slate-700 group-hover:border-blue-500/30 transition-colors">
                    <Code className="text-blue-400 mb-2" />
                    <h4 className="font-semibold">Python Mastery</h4>
                 </div>
                 <div className="p-4 bg-slate-800 rounded-xl border border-slate-700 group-hover:border-purple-500/30 transition-colors">
                    <BrainCircuit className="text-purple-400 mb-2" />
                    <h4 className="font-semibold">Neural Networks</h4>
                 </div>
                 <div className="p-4 bg-slate-800 rounded-xl border border-slate-700 group-hover:border-green-500/30 transition-colors">
                    <Rocket className="text-green-400 mb-2" />
                    <h4 className="font-semibold">Model Deployment</h4>
                 </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Programs;

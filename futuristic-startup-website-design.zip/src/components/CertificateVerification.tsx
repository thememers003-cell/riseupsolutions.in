import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { CheckCircle, XCircle, Loader2, Search } from 'lucide-react';

const CertificateVerification = () => {
  const [certId, setCertId] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'valid' | 'invalid'>('idle');

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!certId) return;

    setStatus('loading');
    
    // Simulate API call
    setTimeout(() => {
      if (certId === 'VALID123') {
        setStatus('valid');
      } else {
        setStatus('invalid');
      }
    }, 1500);
  };

  return (
    <section id="verify" className="py-24 bg-black text-white relative">
      <div className="absolute inset-0 bg-grid-pattern opacity-10" />
      
      <div className="container mx-auto px-4 relative z-10 flex flex-col items-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-blue-500 font-semibold tracking-wider uppercase mb-2">Verification</h2>
          <h3 className="text-3xl md:text-4xl font-bold">Verify Certificate</h3>
          <p className="text-gray-400 mt-4 max-w-lg mx-auto">
            Ensure the authenticity of a RiseUp Solutions certificate by entering the unique credential ID below.
          </p>
        </motion.div>

        <div className="w-full max-w-md bg-slate-900/80 backdrop-blur-lg border border-slate-700 rounded-2xl p-8 shadow-2xl">
          <form onSubmit={handleVerify} className="space-y-4">
            <div className="relative">
              <Search className="absolute left-4 top-3.5 text-gray-500" size={20} />
              <input
                type="text"
                value={certId}
                onChange={(e) => {
                  setCertId(e.target.value);
                  setStatus('idle');
                }}
                placeholder="Enter Certificate ID (e.g. VALID123)"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg py-3 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder-gray-500"
              />
            </div>
            <button
              disabled={status === 'loading'}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 rounded-lg transition-colors flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {status === 'loading' ? (
                <>
                  <Loader2 className="animate-spin" size={20} /> Verifying...
                </>
              ) : (
                'Verify Now'
              )}
            </button>
          </form>

          <AnimatePresence mode='wait'>
            {status === 'valid' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="mt-6 p-4 bg-green-900/20 border border-green-500/50 rounded-lg flex items-start gap-3"
              >
                <CheckCircle className="text-green-500 shrink-0" size={24} />
                <div>
                  <h4 className="font-bold text-green-400">Valid Certificate</h4>
                  <p className="text-sm text-green-200/80">Issued to John Doe for AI Bootcamp. Date: Oct 2023.</p>
                </div>
              </motion.div>
            )}

            {status === 'invalid' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="mt-6 p-4 bg-red-900/20 border border-red-500/50 rounded-lg flex items-start gap-3"
              >
                <XCircle className="text-red-500 shrink-0" size={24} />
                <div>
                  <h4 className="font-bold text-red-400">Invalid Certificate</h4>
                  <p className="text-sm text-red-200/80">The ID provided does not match our records. Please check and try again.</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};

export default CertificateVerification;

import { motion } from 'framer-motion';
import { BookOpen, Hammer, Rocket, Award } from 'lucide-react';

const HowItWorks = () => {
  const steps = [
    {
      icon: <BookOpen className="h-8 w-8 text-blue-400" />,
      title: "Learn",
      description: "Master foundational concepts through expert-curated modules."
    },
    {
      icon: <Hammer className="h-8 w-8 text-purple-400" />,
      title: "Build",
      description: "Apply your knowledge by building mini-projects and solving challenges."
    },
    {
      icon: <Rocket className="h-8 w-8 text-pink-400" />,
      title: "Work",
      description: "Join a real startup team and contribute to live production code."
    },
    {
      icon: <Award className="h-8 w-8 text-yellow-400" />,
      title: "Experience",
      description: "Earn a verified certificate and a portfolio that gets you hired."
    }
  ];

  return (
    <section id="how-it-works" className="py-24 bg-slate-900 text-white relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-blue-900/20 blur-[100px] rounded-full pointer-events-none" />

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-blue-500 font-semibold tracking-wider uppercase mb-2">Process</h2>
          <h3 className="text-4xl font-bold">How RiseUp Works</h3>
        </motion.div>

        <div className="relative">
          {/* Connecting Line (Desktop) */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-gradient-to-r from-blue-900 via-purple-900 to-blue-900 -translate-y-1/2 z-0" />
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2, duration: 0.5 }}
                className="relative z-10 flex flex-col items-center text-center group"
              >
                <div className="w-20 h-20 rounded-full bg-slate-800 border-4 border-slate-900 flex items-center justify-center mb-6 shadow-xl group-hover:scale-110 transition-transform duration-300 group-hover:border-blue-500/50">
                  {step.icon}
                </div>
                <h4 className="text-xl font-bold mb-3">{step.title}</h4>
                <p className="text-gray-400 text-sm max-w-[200px]">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;

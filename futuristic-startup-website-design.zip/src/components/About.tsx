import { motion } from 'framer-motion';

const About = () => {
  return (
    <section id="about" className="relative py-24 bg-slate-900 overflow-hidden text-white">
      {/* Background Gradients */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-purple-900/10 rounded-full blur-[80px]" />
        <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-blue-900/10 rounded-full blur-[60px]" />
      </div>

      <div className="container mx-auto px-4 relative z-10 flex flex-col items-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl text-center space-y-8"
        >
          <h2 className="text-sm font-medium tracking-wide uppercase text-blue-400">
            About RiseUp Solutions
          </h2>
          <h3 className="text-3xl md:text-5xl font-bold leading-tight">
            We Connect Potential with Opportunity
          </h3>
          <p className="text-lg md:text-xl text-gray-300 leading-relaxed">
            RiseUp Solutions is more than just a training platform. We are a launchpad for future tech leaders. 
            By bridging the gap between academic learning and industry demands, we empower students to work on 
            <span className="text-white font-semibold"> live startup projects</span>, gain <span className="text-white font-semibold">real-world experience</span>, 
            and build a portfolio that stands out.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 w-full max-w-6xl">
          {[
            {
              title: "Real Projects",
              desc: "Work on actual software used by real users, not just toy apps.",
              icon: "🚀",
            },
            {
              title: "Mentorship",
              desc: "Learn directly from industry experts who have built scalable systems.",
              icon: "👨‍🏫",
            },
            {
              title: "Career Growth",
              desc: "Get internship certificates and job referrals upon completion.",
              icon: "📈",
            },
          ].map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.5 }}
              className="p-8 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors group"
            >
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                {item.icon}
              </div>
              <h4 className="text-xl font-bold mb-3">{item.title}</h4>
              <p className="text-gray-400">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;

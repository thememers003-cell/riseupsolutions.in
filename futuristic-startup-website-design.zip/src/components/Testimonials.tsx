import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

const testimonials = [
  {
    name: "Sarah Jenkin",
    role: "Frontend Developer at Vercel",
    batch: "Batch 2023",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
    text: "RiseUp Solutions gave me the confidence to build production-ready apps. The mentorship was invaluable and the projects were challenging but rewarding."
  },
  {
    name: "David Chen",
    role: "AI Engineer at OpenAI",
    batch: "Batch 2022",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    text: "The AI Bootcamp was intense. I learned more in 12 weeks than I did in 4 years of college. The hands-on approach is exactly what the industry needs."
  },
  {
    name: "Emily Davis",
    role: "Product Designer at Stripe",
    batch: "Batch 2023",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
    text: "From zero to hero. The design principles and clean code practices I learned here set me apart during interviews. Highly recommended!"
  }
];

const Testimonials = () => {
  const [current, setCurrent] = useState(0);

  const next = () => setCurrent((curr) => (curr + 1) % testimonials.length);
  const prev = () => setCurrent((curr) => (curr - 1 + testimonials.length) % testimonials.length);

  useEffect(() => {
    const timer = setInterval(next, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="testimonials" className="py-24 bg-slate-900 text-white overflow-hidden relative">
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-purple-900/10 blur-[100px] rounded-full pointer-events-none" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-blue-500 font-semibold tracking-wider uppercase mb-2">Success Stories</h2>
          <h3 className="text-4xl font-bold">Hear from our Alumni</h3>
        </div>

        <div className="max-w-4xl mx-auto relative">
          <div className="absolute -top-12 -left-12 text-blue-500/20">
            <Quote size={120} />
          </div>

          <div className="bg-slate-800/50 backdrop-blur-md rounded-3xl p-8 md:p-12 border border-slate-700 shadow-2xl relative overflow-hidden">
             <AnimatePresence mode='wait'>
                <motion.div
                  key={current}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.5 }}
                  className="flex flex-col md:flex-row items-center gap-8"
                >
                  <div className="w-32 h-32 flex-shrink-0">
                    <img 
                      src={testimonials[current].image} 
                      alt={testimonials[current].name} 
                      className="w-full h-full rounded-full object-cover border-4 border-blue-500/30"
                    />
                  </div>
                  <div className="flex-1 text-center md:text-left">
                    <p className="text-xl md:text-2xl text-gray-300 italic mb-6">"{testimonials[current].text}"</p>
                    <div>
                      <h4 className="text-xl font-bold text-white">{testimonials[current].name}</h4>
                      <p className="text-blue-400">{testimonials[current].role}</p>
                      <p className="text-sm text-gray-500 mt-1">{testimonials[current].batch}</p>
                    </div>
                  </div>
                </motion.div>
             </AnimatePresence>

             <div className="flex justify-center md:justify-end gap-4 mt-8">
               <button onClick={prev} className="p-3 rounded-full bg-slate-700 hover:bg-blue-600 transition-colors text-white">
                 <ChevronLeft size={24} />
               </button>
               <button onClick={next} className="p-3 rounded-full bg-slate-700 hover:bg-blue-600 transition-colors text-white">
                 <ChevronRight size={24} />
               </button>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
